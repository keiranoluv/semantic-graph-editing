# Source map for numeric claims (frozen report at commit 927bf29c)

Base URL: https://github.com/keiranoluv/semantic-graph-editing/blob/927bf29c4536a3fb951099a27362be4ac007fc17/

| Report section | Primary artifact |
|---|---|
| Ch. 1 and course requirements | Project01_Graph_Editing.pdf (user supplied) |
| Ch. 2 / Ch. 3 VG150 splits and metrics | docs/LEVEL1_REPORT.md |
| Ch. 3 VG150 protocols GC/NG and case analysis | docs/evaluation/PredCls.md; reports/level1/submission/cases/ |
| Ch. 3 GQA five models | reports/level2/gqa-full-v3-results-v1/README.md |
| Ch. 3 AlignG matched numbers | reports/level2/aligng-gqa-fast-v1-results-v1/summary.json; comparison.json |
| Ch. 3 PE-Net adaptation details | docs/LEVEL2_METHOD_DECISION.md |
| Ch. 4 MagicBrush train details, corpus & audit | reports/level2/magicbrush-manual-experiment-v3/README.md; reports/level2/magicbrush-manual-v3-error-analysis-v1/README.md |
| Ch. 4 MagicBrush mean micro-F1 | User-provided Codex status summary (3.75%, 7.34%); not a public result JSON linked in this source ZIP |
| Ch. 4 EMNLP test results | reports/level2/emnlp2020-task-b-wandb-v4-test-v1/README.md |
| Ch. 5 edited images and SGG pipeline | docs/LEVEL3_PIPELINE.md; docs/LEVEL3_QWEN200_EXTENSION_V1.md |
| Ch. 5 G/E/P, human labels, correlation, 10 cases | docs/LEVEL3_RESULTS_V1.md; docs/LEVEL3_EVALUATION.md |

The source map distinguishes public GitHub reports from the user-supplied status summary.