# Checklist hoàn thiện hồ sơ trước khi nộp

Báo cáo LaTeX đã có nội dung sáu chương và biên dịch được, nhưng các mục sau cần bằng chứng/xác nhận cuối của nhóm. Không đánh dấu đã hoàn thành chỉ vì báo cáo có mô tả.

- [ ] Các thành viên xác nhận bảng đóng góp cá nhân theo lịch sử commit; đối chiếu họ tên/MSSV và người hướng dẫn ở trang bìa.
- [ ] Trao đổi với giảng viên về việc dùng EMNLP 2020 làm thực nghiệm bổ sung/thay nguồn chính Task 2.
- [ ] Kiểm tay một mẫu riêng từ dữ liệu EMNLP; 20 mẫu MagicBrush không thay cho kiểm chứng đó.
- [ ] Hoàn thiện data card, nguồn và bằng chứng giấy phép từng ảnh trong bộ VN100; rà soát quyền riêng tư ảnh nhận diện được người/biển số.
- [ ] Kiểm định ngẫu nhiên độ tin cậy của REACT++; 10 ca bất đồng được chọn có chủ đích không phải mẫu ngẫu nhiên.
- [ ] Hoàn thiện notebook demo nối graph nguồn → instruction → thao tác do mô hình Task 2 dự đoán → graph đích → ảnh chỉnh sửa và consistency score.
- [ ] Làm rõ VG150 PE-Net chưa chạy chính, trạng thái held-out test và phạm vi thực nghiệm một seed ở Task 3.
- [ ] Kiểm tra quyền truy cập local artifacts, checkpoint, W&B và tái lập một thí nghiệm nhỏ trên máy trình bày.
- [ ] Chuẩn bị slide, video dự phòng không quá 5 phút và minh chứng mã nguồn mở/công cụ AI đã sử dụng.

**Mốc số liệu:** commit `927bf29c`, ngày 16/11/2026. Xem `SOURCE_MAP.md`.