# Bao cao do an Graph Machine Learning - LaTeX source

Tieu de: Bieu dien do thi ngu nghia cho chinh sua anh co kiem soat.

## Build (XeLaTeX + Biber)

```bash
latexmk -xelatex -interaction=nonstopmode -halt-on-error main.tex
```

Hoac: xelatex main.tex; biber main; xelatex main.tex; xelatex main.tex.

## Structure

- `main.tex`: entry point; cover, abstract, TOC, chapters, references.
- `header.tex`: page style, font, tables, diagrams, citations.
- `front-page.tex`: cover and members supplied in the original template.
- `abstract.tex`: executive abstract.
- `Text/1.tex` ... `Text/6.tex`: six complete sections.
- `ref.bib`: references (paper metadata and model cards).
- `logo.png`: school logo from the original provided ZIP.
- `SOURCE_MAP.md`: source-of-truth map from results to repository paths.

## Scope and caveats

- Results are grounded in repository `keiranoluv/semantic-graph-editing` main at `927bf29c4536a3fb951099a27362be4ac007fc17` and the supplied project description / experiment status.
- VG150 and custom-GQA main tables are *validation*, not independent test results.
- MagicBrush and EMNLP are different protocols; do not interpret score differences as a matched model improvement.
- The 200-image-edit benchmark has graph score coverage 91/200; missing scores are not imputed.
- Local image/checkpoint artifacts are not bundled; the report includes analytical schematic diagrams generated in LaTeX.
- The cover lists 5 members but the per-person contribution table in Section 6 must be verified by the group; no personal contributions are fabricated.
- A final license/evidence card for every benchmark photo, a human review of EMNLP, and a connected end-to-end notebook are still outstanding in repository status.
- The experiment descriptions reflect available evidence, not a guarantee every requirement of the original assignment is already complete.

PDF preview is distributed separately. The ZIP is editable and intentionally does not include downloaded datasets or model weights.